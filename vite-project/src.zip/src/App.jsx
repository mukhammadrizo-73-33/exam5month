import { useState } from 'react';
import Navbar from "./layout/Navbar";
import './App.css'
import MainPage from './pages/main';
import ThemeContext from './context/ThemeContext';
function App() {
  const [theme, setTheme] = useState('light');
  return (
    <div className="App">
  <Navbar state={setTheme}></Navbar>
  <ThemeContext.Provider value={theme}>
      <MainPage></MainPage>
    </ThemeContext.Provider>
    </div>
  )
}

export default App
