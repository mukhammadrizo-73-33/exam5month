import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';
const getInvoices = createAsyncThunk(
    'invoices/getInvoices',
    async function () {
        const res = axios.get("http://167.235.158.238:3001/invoices");
        return res.data
    }
)

export const { actions: invoicesActions, reducer: invoicesReducer } = createSlice({
    name: "user",
    initialState: {
        invoices: [],
        loading: false
    },
    reducers: {
        setInvoices: (state, actions) => {
            state.invoices = actions.payload
        }
    },
    extraReducers: (builder) => {
        builder.addCase(getInvoices.fulfilled, (state, action) => {
            state.invoices = action.payload;
            state.loading = false;
        })
        builder.addCase(getInvoices.pending, (state) => {
            state.loading = true;
        })
        builder.addCase(getInvoices.rejected, (state, action) => {
            if (action.payload) {
                state.error = action.payload.errorMessage
            } else {
                state.error = action.error.message
            }
        })
    }
}
)
