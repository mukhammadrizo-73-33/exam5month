import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ButtonChange from "../utilits/buttonChange/button";
import { getAccessToken } from "../utilits/localStorage";
import PadingButton from "../utilits/paidingButton/PaidingButton";
function View({ user }) {
   let token= localStorage.getItem("accessToken")
   let b=user.paid;
   const [paid,setPaid]=useState(b)
   console.log(paid,'ededdddddddddddddddddddd',user.paid,b);
   const [click,setClick]=useState(false)
   console.log(token);
   const navigate = useNavigate();
   const deleteInvoice=()=>{
        console.log(token,'deletelogin');
        if (!token) {
            navigate("/login")
            console.log("deleteinvoisesese");
        }
        else{
          console.log('asasasasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
          axios.delete(`http://167.235.158.238:3001/invoices/${user.id}`,{
            headers: {
                Authorization: `Bearer ${token}`
            }
          }).then(()=>{
            navigate(-1)
          })
        }
    }
    function ChangePaid() {
        setClick(true);
        console.log("mkmk");
        console.log('meeeeee',user.paid,paid,!paid);
        console.log('meeeeee',paid);
        if (!token) {
            navigate("/login");
            console.log("deleteinvoisesese");

        }
        else{
            setPaid(paid=>paid?false:true);
            user.paid=paid;
            let obj={
                "userId": 2,
                "paid": paid,
                "email": user.email,
                "to": user.to,
                "dueDate": user.dueDate,
                "term": user.term,
                "createdDate": user.createdDate,
                "description": user.description,
                "price": user.price
            }
        
          
          const a=  axios.put(`http://167.235.158.238:3001/invoices/${user.id}`,obj,{
                headers: {
                    Authorization: `Bearer ${token}`
                }
              }).then(()=>{
               console.log('edited user');
              })  
        }
      
      

    }
   

    return <div className="invoiceUser">
        <div className="status">
            <span className="paragraph">Status</span>
            <PadingButton paid={user.paid}></PadingButton>
        </div>
        <div className="status">
            <ButtonChange type='edit'>Edit</ButtonChange>
            <ButtonChange type='delete' ><span onClick={deleteInvoice}>Delete</span></ButtonChange>
            <ButtonChange type="mark" className="mark" ><span onClick={ChangePaid}>Mark as Paid</span></ButtonChange>
        </div>
    </div>
}
export default View