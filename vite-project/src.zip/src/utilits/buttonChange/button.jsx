import React, { Children } from "react";
import { Btn } from "./style";
const ButtonChange = (props) => {
    const {type}=props;
    // console.log(type)
    return <Btn type={type}>
        {props.children}
    </Btn>
}
export default ButtonChange