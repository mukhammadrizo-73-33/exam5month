import React from "react";
import style from './button.module.css';
const Button=(promp)=>{
const {value,children}=promp
return <button className={style.button}>{children}</button>

}
export default Button