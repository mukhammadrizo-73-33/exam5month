import React from 'react';
import { Button, Cascader, Checkbox, Col, Form, Input, InputNumber, Row, Select } from 'antd';
import FormItem from 'antd/es/form/FormItem';

function Edit() {
    return <div className="invoiceUser edit">
        <h2>Edit <span className='paragraph'>#</span>XM9141</h2>
        <Form layout="vertical" >
            <Form.Item label="Street Address">
                <Input name="address" />
            </Form.Item>
            <FormItem className='display'>
            <Row gutter={16}>
                <Col className="gutter-row" span={8}>
                <Form.Item name="city" label="City" >
                <Input />
            </Form.Item></Col>
            <Col className="gutter-row" span={8}>
            <Form.Item name="post" label="Post Code">
                <Input />
            </Form.Item>
            </Col>
            <Col className="gutter-row" span={8}>
            <Form.Item name="city" label="Country">
                <Input/>
            </Form.Item>
            </Col>
            
            </Row>
            
            </FormItem>
          <FormItem name="clientName" label="Client's Name">
            <Input></Input>
          </FormItem>
          <FormItem name="clientName" label="Client's Name">
            <Input></Input>
          </FormItem>
          <Form.Item
      name={['user', 'email']}
      label="Email"
      rules={[
        {
          type: 'email',
        },
      ]}
    >
      <Input />
    </Form.Item>

        </Form>

    </div>
}
export default Edit
