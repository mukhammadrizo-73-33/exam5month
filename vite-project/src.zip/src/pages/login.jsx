import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { setAccessToken,getAccessToken } from '../utilits/localStorage';
function Login() {
    const [email, setEmail] = useState(''); 
    const navigate=useNavigate();
    const [password, setPassword] = useState(null);
    function handleChangeEmail(e) {
        setEmail(e.target.value)
    }
    function handleChangePassword(e) {
        setPassword(e.target.value)
    }
    function submit(e) {
        e.preventDefault();
        axios.post("http://167.235.158.238:3001/login",{
            email,password
        }
        ).then((res)=>{
            console.log("login boldi",res.data.accessToken);
            setAccessToken(res.data.accessToken);
            navigate(-1)
        })
    }
    return <div>Login
        <form onSubmit={submit}>
            <input type="email" placeholder='email' onChange={handleChangeEmail} />
            <input type="password" placeholder='password' onChange={handleChangePassword} />
            <button type='submit'>Submit</button>
        </form>
    </div>
}
export default Login

