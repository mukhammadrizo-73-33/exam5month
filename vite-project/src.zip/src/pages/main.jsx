import React, { useContext } from "react";
import Main from "../layout/Main";
import ThemeContext from "../context/ThemeContext";
import InvoiceView from "./invoiceView";
import Login from "./login";
import { Route,Routes } from "react-router-dom";
import NewInvoice from "./newInvoice";
import NotFound from "./notFound";
import Edit from "./edit";
function MainPage() {
    const theme = useContext(ThemeContext);
      return  <main className={`theme theme-${theme}`}>
        <Routes>
            <Route path="/" element={<Main/>}>
            </Route>
            <Route path="/invoices" element={<Main/>}>
            </Route>
            <Route path="/invoices/:id" element={<InvoiceView></InvoiceView>}></Route>
            <Route path="/login" element={<Login></Login>}></Route>
            <Route path="/edit" element={<Edit></Edit>}></Route>
            <Route path='/newinvoice' element={<NewInvoice></NewInvoice>}></Route>
            <Route path="*" element={<NotFound></NotFound>}></Route>
        </Routes>
        </main>
}
export default MainPage